
document.querySelectorAll('.topnav button').forEach(btn=>{
 btn.onclick=()=>{
   document.querySelectorAll('.topnav button').forEach(b=>b.classList.remove('active'));
   btn.classList.add('active');
   document.querySelectorAll('.section').forEach(sec=>sec.classList.remove('active'));
   document.getElementById(btn.dataset.section).classList.add('active');
 }
});
